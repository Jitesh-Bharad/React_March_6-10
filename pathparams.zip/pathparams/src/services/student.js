
const students=[
    {name:'ramesh verma',rollno:'cs1',marks:99,dept:'cs',email:'ramesh@gmail.com',mobile:'9999000000',address:{hno:23,city:'pune',state:'MH',pincode:787878,country:'India'}},

    {name:'suresh verma',rollno:'it2',marks:38,dept:'it',email:'suresh@gmail.com',mobile:'9999000001',address:{hno:23,city:'pune',state:'MH',pincode:787878,country:'India'}},
        
    {name:'john cena',rollno:'ec9',marks:100,dept:'ec',email:'john@cena.com',mobile:'1999000000',address:{hno:3,city:'bengaluru',state:'KA',pincode:560030,country:'India'}},
        
    {name:'ranjeet',rollno:'mech3',marks:100,dept:'Mech',email:'ranjeet@gmail.com',mobile:'999909999',address:{hno:19,city:'bengaluru',state:'KA',pincode:560037,country:'India'}},
       
    {name:'mahesh verma',rollno:'EE1',marks:99,dept:'EE',email:'mahesh@gmail.com',mobile:'8999000000',address:{hno:23,city:'pune',state:'MH',pincode:782728,country:'India'}}
]

export function getAll()
{
    return Promise.resolve(students);
}

export function getByRollNo(rollno)
{
    let arr=students.filter((student)=>(student.rollno==rollno));
    console.log(arr[0]);
    if(arr.length==0)
    {
      return  Promise.reject('Invalid roll no.');       
    }
    else{
      return  Promise.resolve(arr[0]);
    }
}