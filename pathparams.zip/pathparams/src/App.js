import logo from './logo.svg';
import './App.css';
import { StudentList } from './components/StudentList';
import { Container } from 'react-bootstrap';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { StudentDetails } from './components/StudentDetails';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<StudentList/>}/>
      <Route path='/detail/:rollno' element={<StudentDetails/>}/>      
    </Routes>
    </BrowserRouter>    
  );
}

export default App;
