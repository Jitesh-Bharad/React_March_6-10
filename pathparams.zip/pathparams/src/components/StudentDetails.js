import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getByRollNo } from "../services/student";
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

export function StudentDetails()
{
   const [detail,setDetail]=useState({});
   const [loading,setLoading]=useState(false);
   const params=useParams();
 
    useEffect(()=>{
       async function getDetail()
       {
        setLoading(true);
        let d=await getByRollNo(params['rollno']);
        setDetail(d);
        setDetail({...detail,address:d.address});
        setLoading(false);
       }
       getDetail();
    },[])

    if(loading){
        return (<p>...Loading</p>)
    }
    else{
        return (
            <Card style={{ width: '18rem' }}>
            <Card.Body>
              <Card.Title>{detail.name}</Card.Title>
              <Card.Text>Email : {detail.email}</Card.Text>
              <Card.Text>Mobile : {detail.mobile}</Card.Text>
              <Card.Text>Marks :{detail.marks}</Card.Text>
              <Card.Text>Marks :{detail.address.hno}</Card.Text>              
              </Card.Body>
          </Card>
     
        )
    }

}
