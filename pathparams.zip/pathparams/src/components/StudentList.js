import { useEffect, useState } from "react";
import { Button, Table } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { getAll } from "../services/student";

export function StudentList()
{
    const [students,setStudents]=useState([]);
    const [loading,setLoading]=useState(false);
    const navigate=useNavigate();

    function goToDetail(rollno)
    {
        console.log(rollno);
        navigate(`/detail/${rollno}`);
    }

    useEffect(()=>{
        async function getAllStudents()
        {
        setLoading(true);
          let all=await getAll();
          setStudents(all);
          setLoading(false);
        }
        getAllStudents();
    },[])

    if(loading){
        return (
            <p>...Loading</p>
        )
    }
    else{
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Mobile</th>
          <th>Details</th>          
        </tr>
      </thead>
      <tbody>
        {students.map((student)=>(
            <tr key={student.rollno}>
                <td>{student.name}</td>
                <td>{student.email}</td>
                <td>{student.mobile}</td>
                <td><Button onClick={()=>{goToDetail(student.rollno)}} variant="success">View Detail</Button></td>
            </tr>            
        ))}
      </tbody>
    </Table>
  );
    }
}

    