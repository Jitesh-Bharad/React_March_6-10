import React from "react";
import { Child } from "./Child";

export function Parent(){

    function getDataFromChild(age){
        console.log(`data from child in parent : ${age}`);                
    }

    function getUpdatedMarks(marks)
    {
        console.log(`updated marks ${marks}`);
    }

    return (
        <>
         <p>Parent Component</p>
         <Child marks={90} onGetUpdatedMarks={getUpdatedMarks} onGetAge={getDataFromChild} name='abcdef'></Child>        
         </>
    )
}