export function ValidationErrorWrapper(props)
{
    return (
        <span style={{color:'red',fontWeight:'bold',fontSize:'12px'}}>
            {props.children}
        </span>
    )
}