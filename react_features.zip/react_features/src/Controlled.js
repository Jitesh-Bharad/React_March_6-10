import React from "react";
import { ValidationErrorWrapper } from "./ValidationErrorWrapper";

export class Controlled extends React.Component{

    constructor(props)
    {
        super(props);
        this.state={name:'',email:'',password:''};
    }

    handleChangeName=(e)=>
    {
        this.setState({name:e.target.value});
    }
    handleChangeEmail=(e)=>
    {
        this.setState({email:e.target.value});        
    }    
    handleChangePassword=(e)=>
    {
        this.setState({password:e.target.value});       
    }

    handleSubmit=(e)=>
    {
        e.preventDefault();
        console.log(this.state);
    }

    render()
    {
        return (
        <form onSubmit={this.handleSubmit}>
            <div>
            <input onChange={this.handleChangeName} type='text' placeholder="Enter name"/>
            {/* {this.state.name.length<3?<span>Name is invalid</span>:null} */}
            { this.state.name.length<3 && <ValidationErrorWrapper>Name is invalid</ValidationErrorWrapper>}
            </div>
            <div>
            <input onChange={this.handleChangePassword} type='password' placeholder="Enter password"/>
            { this.state.password.length<8 && <ValidationErrorWrapper>Password is invalid</ValidationErrorWrapper>}
            </div>
            <div>
            <input onChange={this.handleChangeEmail} type='email' placeholder="Enter email"/>            
            </div>
            <button disabled={ (this.state.name.length<3) || (this.state.password.length<8)} type="submit">Submit</button>
        </form>
        );
    }
}


// 1. Controlled Forms : 
// Forms where the field values are controlled by react using State 

// 2. Uncontrolled Forms : State is not used to manage the input/field values . Will make use of ref

//Wrapper Component : Wrapper components are the components that surround some unknown components, and they will provide a default structure with optional styling to any component that need to be displayed. Generally wrapper components are used to create UI elements that are used frequently in the applications, like Dialog Box .


















