export function WrapperComp(props)
{
    return(
        <>
        <h3>Wrapper Component</h3>
        {props.children}
        </>    
    )
}