import { useState } from "react"

export function ChildWithState({name,onGetAge})
{
   const [age,setAge]= useState();

    return (
        <>
        <p>Child Starts</p>
        <input onChange={(e)=>{setAge(e.target.value)}} type='number' placeholder="Enter age"/>
        <p>Name From Parent : {name}</p>
        <button onClick={()=>onGetAge(age)}>Send Age to parent</button>
        </>
    )
}