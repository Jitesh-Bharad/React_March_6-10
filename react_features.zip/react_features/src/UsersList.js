import React from "react";
export class UsersList extends React.Component{

    constructor(props)
    {
        super(props);

        this.state={user:{name:'',rollno:'',marks:0},users:[]}
    }

    async componentDidMount()
    {
        try{
            
        }catch(error)
        {
        }
    }

    handleChangeName=(e)=>{
        this.setState({user:{...this.state.user,name:e.target.value}});
    }

    handleChangeRollno=(e)=>{
        this.setState({user:{...this.state.user,rollno:e.target.value}});
    }
    
    handleChangeMarks=(e)=>{
        this.setState({user:{...this.state.user,marks:e.target.value}});
    }
  
    handleSubmit=(e)=>{
        e.preventDefault();
        this.setState((prevState)=>{return { users:[...prevState.users,prevState.user] }});
    }


    render()
    {
        return(
            <>
        <form onSubmit={this.handleSubmit}>
            <input type='text' onChange={this.handleChangeName} placeholder="Enter name"/>
            <input type='rollno' onChange={this.handleChangeRollno} placeholder="Enter rollno"/>
            <input type='marks' onChange={this.handleChangeMarks} placeholder="Enter marks"/>            
            <button type="submit">Submit</button>
        </form>

        <table>
            <thead>
                <tr>
                <th>Name</th>
                <th>Rollno</th>
                <th>Marks</th>
                </tr>
            </thead>
            <tbody>
            {this.state.users.map((user,index)=>{
                return (<tr key={index}>
                      <td>{user.name}</td>  
                      <td>{user.rollno}</td>  
                      <td>{user.marks}</td>  
                </tr>)
            })}
            </tbody>
        </table>
            </>
        );
    }    
}