import React from "react";
// export class  PureImpure extends React.PureComponent
export class  PureImpure extends React.Component
{

    //Component extending React.PureComponent will re-render every time any of the props value
    //changes. For example there are 3 props and we need to re-render the child on update of only 1 prop , but it will re-render the child component even in the cases where other 2 props also change. Such kind of control is not avaialble in components extending React.PureComponent but such kind of control is available in the component if we override the shouldComponentUpdate() lifecyle of the component.
    constructor(props)
    {
        super(props);
    }

    shouldComponentUpdate(nextProps)
    {
        if(this.props.name==nextProps.name)
        {
            return false;            
        }
        return true;
    }

    render()
    {
        console.log('child render')
        return (
            <>        
            <p>Child </p>
            <p>Name From parent : {this.props.name}</p>
            </>
        )    
    }
}