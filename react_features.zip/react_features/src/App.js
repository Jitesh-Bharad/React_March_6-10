import logo from './logo.svg';
import './App.css';
import { List } from './List';
import { Parent } from './Parent';
import { StateFunctional } from './StateFunctional';
import { ParentWithState } from './ParentWithState';
import { Student } from './Student';
import { ParentPureImpure } from './ParentPureImpure';
import { Uncontrolled } from './Uncontrolled';
import { Controlled } from './Controlled';
import { WrapperComp } from './WrapperComp';
import { UsersList } from './UsersList';

function App() {
  return (
    <UsersList></UsersList>
    // <List></List>
    // <Parent></Parent>
    // <StateFunctional></StateFunctional>
    // <ParentWithState></ParentWithState>
    // <Student></Student>
    // <ParentPureImpure></ParentPureImpure>
    // <Uncontrolled></Uncontrolled>
    // <Controlled></Controlled>
    // <>
    // <WrapperComp>
    //   <form>
    //     <input type='text' placeholder='Enter name'/>
    //     <button>Submit</button>
    //   </form>
    // </WrapperComp>

    // <WrapperComp>
    //   <p>Hello World</p>
    // </WrapperComp>

    // </>
  );
}
export default App;
