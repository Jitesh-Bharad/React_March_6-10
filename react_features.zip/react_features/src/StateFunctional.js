import { useState } from "react"

export function StateFunctional()
{
   const [score,setScore]= useState(10);
    return (
        <>
          <p>Score : {score}</p>
          <button onClick={()=>{setScore(score+1)}}>+</button>
          <button onClick={()=>{setScore(score-1)}}>-</button>          
        </>        
    )
}