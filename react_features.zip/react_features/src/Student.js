import { useState } from "react"

export function Student()
{
   const[student,setStudent]=useState({name:'',rollno:'',marks:0});
   
   function handleChangeName(e)
   {
    setStudent({...student,name:e.target.value});
   }

   function handleChangeRollno(e)
   {
    setStudent({...student,rollno:e.target.value});
   }
   function handleChangeMarks(e)
   {    
    setStudent({...student,marks:e.target.value});
   }

   function handleSubmitForm(e)
   {
    e.preventDefault();
    console.log(student);
   }

   return(
        <>
        <form onSubmit={handleSubmitForm}>
            <input onChange={handleChangeName} type='text' placeholder="Enter name"/>
            <input onChange={handleChangeRollno} type='text' placeholder="Enter roll no"/>
            <input onChange={handleChangeMarks} type='number' placeholder="Enter marks"/>
            <button type="submit">Submit</button>
        </form>       
        </>
    )
}
