import React from "react";

export class Uncontrolled extends React.Component{

    constructor(props)
    {
        super(props);
    }

    handleSubmit=(e)=>
    {
        e.preventDefault();
        console.log(this.name.value);
        console.log(this.password.value);
    }

    handleField(varName,input)
    {
        varName=input;
    }

    render()
    {
        return (
        <form onSubmit={this.handleSubmit}>
            <input ref={(x)=>{this.name=x}} type='text' placeholder="Enter name"/>
            <input type='password' ref={(input)=>{this.password=input}} placeholder="Enter password"/>
            <button type="submit">Submit</button>
        </form>
        );
    }
}






// 1. Controlled Forms : 
// Forms where the field values are controlled by react using State 

// 2. Uncontrolled Forms : State is not used to manage the input/field values . Will make use of ref
















