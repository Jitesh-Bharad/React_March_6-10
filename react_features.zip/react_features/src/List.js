export function List()
{
    const x=[1,2,10,100,90,65];
    const cities=['Indore','Pune','Mumbai','Bengaluru','Kolkata'];
    // return (
    // <ul>
    // {x.map( (val,index) => { return <li key={index}>{val}</li>  })}
    // </ul>
    // );
    return (
        <select>
             {cities.map((city,index)=>(<option key={index}>{city}</option>))}           
        </select>
    )    
}










