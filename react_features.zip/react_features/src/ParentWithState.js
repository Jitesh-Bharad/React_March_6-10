import { useState } from "react"
import { ChildWithState } from "./ChildWithState"
export function ParentWithState()
{
    const [name,setName]=useState('');
    const [ageFromChild,setAgeFromChild]=useState(0)
    function getAge(age)
    {
        setAgeFromChild(age);
    }
    return (
        <>
        <p>Parent here</p>        
        <p>Age From Child : {ageFromChild}</p>
        <input onChange={(e)=>setName(e.target.value)} type='text' placeholder="Enter name"/>
        <ChildWithState onGetAge={getAge} name={name}></ChildWithState>
        </>
    )
}