import React from "react";
import { PureImpure } from "./PureImpure";
export class ParentPureImpure extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={name:'',age:0}
    }
    render()
    {
        console.log('parent render')
        return (
            <>
            <p>Parent </p>
            <input type='text' onChange={(e)=>{this.setState({name:e.target.value})}} placeholder="enter name"/>
            
            <input type='number' onChange={(e)=>{this.setState({age:e.target.value})}} placeholder="enter age"/>
            
            <PureImpure name={this.state.name} age={this.state.age}></PureImpure>
            </>        
        )    
    }
}