export function Child(props){
    let age=90;
    return(
        <>
        <p>Child Here</p>
        <p>Data from parent : {props.name}</p>
        <button onClick={()=>{props.onGetAge(age)}}>Send To Parent</button>
        <button onClick={()=>{props.onGetUpdatedMarks(props.marks+2)}}>Update Marks</button>
        </>
    )
}