import { useNavigate } from "react-router-dom"

export function Home()
{
    const navigate=useNavigate();

    function navigateToContact()
    {
        navigate('/contact');
    }

    return (
        <>
        <p>Home</p>
        <button onClick={navigateToContact}>Go to Contact</button>
        </>
    )
}