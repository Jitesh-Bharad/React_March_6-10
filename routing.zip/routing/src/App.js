import logo from './logo.svg';
import './App.css';
import AppBar from './AppBar';
import { BrowserRouter, Route, Routes, useNavigate } from 'react-router-dom';
import { Contact } from './Contact';
import { Home } from './Home';
import { About } from './About';
import { NotFound } from './NotFound';
import { AdminRoutes } from './AdminRoutes';

function App() {
  return (
    <>
    <BrowserRouter>
    <AppBar></AppBar>
     <Routes>
      <Route path='/admin/*' element={<AdminRoutes/>}/>
      <Route path='/' element={<Home></Home>}/>
      <Route path='/home' element={<Home></Home>}/>
      <Route path='/about' element={<About></About>}/>
      <Route path='/contact' element={<Contact></Contact>}/>      
      <Route path='*' element={<NotFound></NotFound>}/>      
     </Routes>
    </BrowserRouter>
    </>
  )
}

export default App;
