export function AdminContact()
{
    return (
        <p>Admin Contact page</p>
    )
}