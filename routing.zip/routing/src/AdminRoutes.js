import { Route,Routes } from "react-router-dom"
import { AdminContact } from "./AdminContact"
import { AdminHome } from "./AdminHome"

export function AdminRoutes(){

    return(<Routes>
        <Route path="home" element={<AdminHome></AdminHome>}></Route>
        <Route path="contact" element={<AdminContact></AdminContact>}></Route>
    </Routes>);
}