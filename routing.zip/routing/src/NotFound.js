import { Container } from "react-bootstrap";

export function NotFound()
{
    return(
        <Container>
            <h2>404</h2>
            <p>Not Found</p>
        </Container>
    )
}