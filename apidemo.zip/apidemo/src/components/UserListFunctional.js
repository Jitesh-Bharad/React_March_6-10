import axios from "axios";
import { useEffect, useState } from "react";

export function UserListFunctional()
{
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(false);
    const [name,setName]=useState('')

    useEffect(()=>{
        async function fetchUsers()
        {
            setLoading(true);
            let url='https://jsonplaceholder.typicode.com/users'; 
            let response=await axios.get(url);    
            console.log(response.data);
            setUsers(response.data);
            setLoading(false);
        }        
        fetchUsers();
    },[])

        if(loading)
        {
            return (<p>...Loading</p>)
        }
        else{
            return (<ul>
                {users.map((user)=>{return <li key={user.id}>{user.name}</li>})}
            </ul>)
        }
    
}