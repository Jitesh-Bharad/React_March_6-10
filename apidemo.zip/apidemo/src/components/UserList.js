import axios from "axios";
import React from "react";
export class UserList extends React.Component{

    constructor(props)
    {
        super(props);
        this.state={users:[],loading:false};
    }
  async componentDidMount()
    {
        this.setState({loading:true});
        let url='https://jsonplaceholder.typicode.com/users';
        
        let response=await axios.get(url);  
        let data=response.data;  
        this.setState({users:data,loading:false});
    }

   render()
    {
        if(this.state.loading){
            return (<p>
                .....Loading
            </p>)
        }else{
            return(
                <ul>
                    {this.state.users.map((user)=>( <li key={user.id}>{user.name}</li>))}
                </ul>
                )    
        }
    }
}