import logo from './logo.svg';
import './App.css';
import { UserList } from './components/UserList';
import { UserListFunctional } from './components/UserListFunctional';

function App() {
  return (
    // <UserList></UserList>
    <UserListFunctional></UserListFunctional>
  )
}

export default App;
