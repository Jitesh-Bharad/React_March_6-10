import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import { taskReducer } from "./reducers/TaskReducer";
import { authReducer } from "./reducers/AuthReducer";

const rootReducer=combineReducers({taskReducer,authReducer});

export const store=configureStore({reducer:rootReducer});