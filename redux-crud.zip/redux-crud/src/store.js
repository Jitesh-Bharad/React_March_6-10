import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import { taskReducer } from "./reducers/TaskReducer";

const rootReducer=combineReducers({taskReducer});

export const store=configureStore({reducer:rootReducer});