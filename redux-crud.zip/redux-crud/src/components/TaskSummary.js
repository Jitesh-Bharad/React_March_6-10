import { Col, Row } from "react-bootstrap";
import { TaskChart } from "./TaskChart";

export function TaskSummary(props)
{
    return (
        <Row style={{marginTop:'3%'}}>
            <Col></Col>
            <Col style={{borderRadius:'12px',height:'200px',boxShadow:'1px 1px 3px 2px lightgrey'}}>
               <h5 style={{marginTop: '40%',textAlign: 'center',fontFamily: 'sans-serif',color: 'cadetblue',textShadow: '2px 1px 1px lightgrey'}}>{props.tasks.length} Tasks</h5>                
            </Col>
            <Col></Col>
            <Col xs={4} style={{borderRadius:'12px',height:'200px',boxShadow:'1px 1px 3px 2px lightgrey'}}>

                <TaskChart data={props.tasks}></TaskChart>

            </Col>
            <Col></Col>
        </Row>
    )
}