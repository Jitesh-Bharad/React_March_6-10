import Chart from "react-google-charts";
import { TASK_STATUS_COMPLETED, TASK_STATUS_IN_PROGRESS, TASK_STATUS_NOT_STARTED } from "../constants/ApiConstants";

export function TaskChart(props)
{
      let mp=new Map();
      let tasks=props.data;
      for(let task of tasks)
      {
          let currentValue=mp.get(task.status);
          mp.set(task.status,(currentValue==undefined)?1:currentValue+1);
      }

      const data = [
        ["Task Status", "Numbers"],
        ["In Progress", mp.get(TASK_STATUS_IN_PROGRESS)?mp.get(TASK_STATUS_IN_PROGRESS):0],
        ["Not Started", mp.get(TASK_STATUS_NOT_STARTED)?mp.get(TASK_STATUS_NOT_STARTED):0],
        ["Completed", mp.get(TASK_STATUS_COMPLETED)?mp.get(TASK_STATUS_COMPLETED):0],
      ];

      console.log(data);
      
      

    return (
        <>
         <Chart
      chartType="PieChart"
      data={data}
      options={{title:"Task Status"}}
      width={"100%"}
      height={"200px"}
    />
        </>
    )
}