import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getTasksRequest } from "../actions/ToDoActions";
import { getAllTasks } from "../services/todo";
import { TaskList } from "./TaskList";
import { TaskSummary } from "./TaskSummary";

export function Dashboard()
{

   const dispatch=useDispatch();
   const tasks=useSelector((state)=>state.taskReducer);

    useEffect(()=>{
        dispatch(getTasksRequest())
    });

    const totalTasks=tasks.length;
        return (
            <>
            <p>Total Tasks : {tasks.length}</p>
           {totalTasks>0?(<TaskSummary></TaskSummary>):null}
            <TaskList data={tasks}></TaskList>
            </>
            )                
}