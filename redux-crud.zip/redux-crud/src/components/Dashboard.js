import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getTasksRequest } from "../actions/ToDoActions";
import { getAllTasks } from "../services/todo";
import AppBar from "./Appbar";
import { TaskList } from "./TaskList";
import { TaskSummary } from "./TaskSummary";
import { logout } from "../actions/AuthAction";

export function Dashboard()
{

   const dispatch=useDispatch();
   const tasks=useSelector((state)=>state.taskReducer);
   const user=useSelector((state)=>state.authReducer);
   const navigate=useNavigate();

    useEffect(()=>{
        // if(user.isLoggedIn){
        //     dispatch(getTasksRequest(user.token))
        // }
        // else{
        //     navigate('/login');
        // }
        dispatch(getTasksRequest(user.token))
    },[]);

    function handleLogout()
    {
        localStorage.clear();
        dispatch(logout());
        navigate('/login');
    }

    const totalTasks=tasks.length;
        return (
            <>
            <AppBar email={user.email} onLogout={handleLogout}></AppBar>
           {totalTasks>0?(<TaskSummary tasks={tasks}></TaskSummary>):null}
            <TaskList data={tasks}></TaskList>
            </>
            )                
}