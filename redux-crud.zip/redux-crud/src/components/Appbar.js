import { Button } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

function AppBar(props) {

  return (
    <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand>Welcome {props.email}</Navbar.Brand>
        <Navbar className='ml-auto' id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link><Button onClick={props.onLogout}>Logout</Button></Nav.Link>
          </Nav>
        </Navbar>
      </Container>
    </Navbar>
  );
}

export default AppBar;