import React, { useState } from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import Table from 'react-bootstrap/Table';
import { useDispatch } from 'react-redux';
import { deleteTaskRequest, saveTaskRequest } from '../actions/ToDoActions';
import { TASK_STATUS_COMPLETED, TASK_STATUS_IN_PROGRESS, TASK_STATUS_NOT_STARTED } from '../constants/ApiConstants';

export function TaskList(props)
{
    const [show, setShow] = useState(false);
    const [task,setTask]=useState({title:'',description:'',status:TASK_STATUS_NOT_STARTED});
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const dispatch=useDispatch();

    function handleChangeTitle(e)
    {
      setTask({...task,title:e.target.value});
    }
    function handleChangeDescription(e)
    {
      setTask({...task,description:e.target.value});
    }
    function handleChangeStatus(e)
    {
      console.log(e.target.value);
      setTask({...task,status:e.target.value});
    }

    const handleAddTask=()=>{
      console.log(task);
      dispatch(saveTaskRequest(task)).then(()=>{setShow(false)});
    }

    function handleDeleteTask(id)
    {
      console.log(id);
      dispatch(deleteTaskRequest(id));
    }
  
  return (
    <>
    <Container style={{marginTop:'3%'}}>
      <Row>
        <Col xs={10}></Col>        
        <Col style={{marginLeft:'3%'}}>
        <Button variant="primary" className='ml-auto' onClick={handleShow}>
        + Add Task
        </Button>
        </Col>
      </Row>
     
      <Table style={{marginTop:'3%'}} striped bordered hover>
      <thead>
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Status</th>
          <th>Delete</th>          
        </tr>
      </thead>
      <tbody>
        {props.data.map((task)=>(<tr key={task.id}>
            <td>{task.title}</td>
            <td>{task.description}</td>
            <td>{task.status}</td>            
            <td><Button onClick={()=>handleDeleteTask(task.id)} className='btn-sm' variant='danger'>Delete</Button></td>                        
        </tr>))}
      </tbody>
    </Table>
    </Container>



      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Title</Form.Label>
              <Form.Control
              onChange={handleChangeTitle}
                type="text"
                placeholder="To Do ..."
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Description</Form.Label>
              <Form.Control onChange={handleChangeDescription} as="textarea" rows={3} />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Status</Form.Label>
              <div>
              <select onChange={handleChangeStatus}>
                <option value={TASK_STATUS_NOT_STARTED}>{TASK_STATUS_NOT_STARTED}</option>
                <option value={TASK_STATUS_IN_PROGRESS}>{TASK_STATUS_IN_PROGRESS}</option>
                <option value={TASK_STATUS_COMPLETED}>{TASK_STATUS_COMPLETED}</option>
              </select>
              </div>                              
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="success" onClick={handleAddTask}>
            Add
          </Button>
        </Modal.Footer>
      </Modal>
    </>

    )
}