import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { loginSuccessRequest } from '../actions/AuthAction';

export function Login()
{
   const [user,setUser]=useState({email:'',password:''});

   const dispatch=useDispatch();
   
   const navigate=useNavigate();

   const authUser=useSelector((state)=>state.authReducer);

   function handleChangeEmail(e)
   {
    setUser({...user,email:e.target.value});
   }

   function handleChangePassword(e)
   {
    setUser({...user,password:e.target.value});
   }
   
   function handleLogin(e)
   {
    e.preventDefault();
    dispatch(loginSuccessRequest(user)).then(()=>navigate('/'))
   }

   useEffect(()=>{
    if(authUser.isLoggedIn){
        navigate('/');
    }
   },[]) 
    return (
        <Form onSubmit={handleLogin}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control onChange={handleChangeEmail} type="email" placeholder="Enter email" />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>
  
        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control onChange={handleChangePassword} type="password" placeholder="Password" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formBasicCheckbox">
          <Form.Check type="checkbox" label="Check me out" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>
          
    )
}
