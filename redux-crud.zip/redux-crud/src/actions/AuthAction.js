import { login } from "../services/authService";
import { LOGIN_SUCCESS, LOGOUT } from "./ActionTypes";

export function loginSuccessRequest(user)
{
    return async function(dispatch)
    {
        try{
            let authUser= await login(user);
            dispatch(loginSuccess(authUser));     
            return Promise.resolve();
        }catch(error)
        {
           return Promise.reject(error);
        }
    }
}

export function loginSuccess(data)
{
    return {
        type:LOGIN_SUCCESS,
        payload:data
    }
}

export function logout()
{
    return {
        type:LOGOUT
    }
}