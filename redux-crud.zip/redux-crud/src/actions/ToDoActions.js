import { deleteTask, getAllTasks, saveTask } from "../services/todo"
import { DELETE_TASK_SUCCESS, GET_TASKS_FAILURE, GET_TASKS_SUCCESS, SAVE_TASK_SUCCESS } from "./ActionTypes";

export function getTasksRequest(token)
{
    return async function(dispatch){
        try{
            let tasks=await getAllTasks(token);
            dispatch(getTasksSuccess(tasks));
            Promise.resolve();
        }catch(error)
        {
            Promise.reject(error);
        }
    }
}

export function saveTaskRequest(task)
{
    return async function(dispatch){
        try{
            let addedTask=await saveTask(task);
            dispatch(saveTaskSuccess(addedTask));
            Promise.resolve();
        }catch(error)
        {
            Promise.reject(error);
        }
    }
}


export function deleteTaskRequest(id)
{
    return async function(dispatch){
        try{
            await deleteTask(id);
            dispatch(deleteTaskSuccess(id));
            return Promise.resolve();
        }catch(error)
        {
           return Promise.reject(error);
        }
    }
}


export function getTasksSuccess(tasks)
{
    return {
        type:GET_TASKS_SUCCESS,
        payload:tasks
    }
}

export function saveTaskSuccess(task)
{
    return {
        type:SAVE_TASK_SUCCESS,
        payload:task
    }
}

export function deleteTaskSuccess(id)
{
    return {
        type:DELETE_TASK_SUCCESS,
        payload:id
    }
}

export function getTasksFailure(error)
{
    return {
        type:GET_TASKS_FAILURE,
        payload:error
    }
}