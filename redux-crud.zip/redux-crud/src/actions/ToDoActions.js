import { getAllTasks } from "../services/todo"
import { GET_TASKS_FAILURE, GET_TASKS_SUCCESS } from "./ActionTypes";

export function getTasksRequest()
{
    return async function(dispatch){
        try{
            let tasks=await getAllTasks();
            dispatch(getTasksSuccess(tasks))
        }catch(error)
        {
            dispatch(getTasksFailure(error));
        }
    }
}

export function getTasksSuccess(tasks)
{
    return {
        type:GET_TASKS_SUCCESS,
        payload:tasks
    }
}

export function getTasksFailure(error)
{
    return {
        type:GET_TASKS_FAILURE,
        payload:error
    }
}