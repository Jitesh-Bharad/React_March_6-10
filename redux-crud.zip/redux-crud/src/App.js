import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Dashboard } from './components/Dashboard';
import { Login } from './components/Login';
import { PrivateRoute } from './components/PrivateRoute';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={ <PrivateRoute><Dashboard></Dashboard></PrivateRoute>}></Route>
      <Route path='/login' element={<Login></Login>}></Route>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
