import axios from "axios";
import { URL } from "../constants/ApiConstants";

function getArrayFromObj(obj)
{
    let tasks=[];
    for(let key in obj)
    {
     let task=obj[key];   
     task={...task,id:key}
     tasks.push(task);
    }    
    return tasks;
}

export async function getAllTasks()
{
  let response=await axios.get(URL);
  let tasks=getArrayFromObj(response.data);
  return Promise.resolve(tasks);
}