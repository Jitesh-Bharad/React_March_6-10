import axios from "axios";
import { URL } from "../constants/ApiConstants";

function getArrayFromObj(obj)
{
    let tasks=[];
    for(let key in obj)
    {
     let task=obj[key];   
     task={...task,id:key}
     tasks.push(task);
    }    
    return tasks;
}

export async function getAllTasks(token)
{
  let response=await axios.get(URL+'todo.json',{params:{auth:token}});
  let tasks=getArrayFromObj(response.data);
  return Promise.resolve(tasks);
}

export async function saveTask(task)
{
  console.log(task);
  let response=await axios.post(URL+'todo.json',task);
  task={...task,id:response.data.name};
  return Promise.resolve(task);
}

export async function deleteTask(id)
{
  let url=URL+'todo/'+id+'.json';
  await axios.delete(url);
  Promise.resolve();  
}