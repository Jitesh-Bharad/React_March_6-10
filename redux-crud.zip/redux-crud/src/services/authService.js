import axios from "axios";
import { LOGIN_SUCCESS } from "../actions/ActionTypes";
import { LOGIN_URL } from "../constants/ApiConstants";


export async function login(user)
{
   user={...user,returnSecureToken:true};
   let response=await axios.post(LOGIN_URL,user);
   let authUser={token:response.data.idToken,email:response.data.email};
   localStorage.setItem('user',JSON.stringify(authUser));
   return Promise.resolve(authUser);
}