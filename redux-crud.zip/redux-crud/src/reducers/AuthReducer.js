import { LOGIN_SUCCESS, LOGOUT } from "../actions/ActionTypes";

const user=JSON.parse(localStorage.getItem('user'));

const initialState=user?{token:user.token,email:user.email,isLoggedIn:true}:{token:'',email:'',isLoggedIn:false};

export function authReducer(user=initialState,action)
{
    const {type,payload}=action;

    switch(type)
    {
        case LOGIN_SUCCESS:
            console.log(payload.token);
            return {token:payload.token,email:payload.email,isLoggedIn:true}
        case LOGOUT:
            return {token:'',email:'',isLoggedIn:false}
        default:
            return user;
    }
}