import { GET_TASKS_SUCCESS } from "../actions/ActionTypes";

const initialState=[];

export function taskReducer(tasks=initialState,action)
{
    const {type,payload}=action;

    switch(type)
    {
        case GET_TASKS_SUCCESS:
            return payload;
        default:
            return tasks;
    }
}