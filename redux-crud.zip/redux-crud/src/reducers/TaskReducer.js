import { DELETE_TASK_SUCCESS, GET_TASKS_SUCCESS, SAVE_TASK_SUCCESS } from "../actions/ActionTypes";

const initialState=[];

export function taskReducer(tasks=initialState,action)
{
    const {type,payload}=action;

    switch(type)
    {
        case GET_TASKS_SUCCESS:
            return payload;
        case SAVE_TASK_SUCCESS:
            return [...tasks,payload]
        case DELETE_TASK_SUCCESS:
            return tasks.filter((task)=>(task.id!=payload))
        default:
            return tasks;
    }
}