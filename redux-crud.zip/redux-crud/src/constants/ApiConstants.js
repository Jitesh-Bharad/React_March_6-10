export const URL='https://todo-a7bd9-default-rtdb.firebaseio.com/';
export const LOGIN_URL ='https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyBiVZ5fJxekZlhAHLgBfs7UiI8C40E1kQw'


export const TASK_STATUS_COMPLETED='Completed';
export const TASK_STATUS_NOT_STARTED='Not Started';
export const TASK_STATUS_IN_PROGRESS='In Progress';

