import style from './CompB.module.css';

export function CompB()
{
    return (
        <div className={style.theme}>
        <h3>Comp B here</h3>
        <p>para1 of component B </p>
        </div>
    )
}