import { useState } from 'react';
import './Conditional.css';

export function ConditionalStyleState()
{
   const [theme,setTheme]=useState('d');   
   
   let classApplicable=(theme=='d')?'dark':'light';

   function handleChangeTheme(e)
   {
    setTheme(e.target.value);
   }

   return (
        <div className={classApplicable}>           
        <select onChange={handleChangeTheme}>
            <option value='l'>Light</option>
            <option value='d'>Dark</option>
        </select> 
        <h3>Hello</h3>
        <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ornare ante et facilisis pellentesque. Sed mollis sollicitudin ante in aliquet. Vivamus fringilla leo ac odio ornare, eget facilisis nisl placerat. Nam blandit pretium dui et hendrerit. Pellentesque pellentesque quam eu viverra congue. Sed et mattis leo. Morbi ut venenatis urna. Duis vitae quam sit amet felis ornare blandit quis sit amet felis. In hac habitasse platea dictumst. Praesent venenatis ipsum pretium cursus efficitur. Donec scelerisque ultrices enim quis bibendum. Integer sodales lacus nec nibh varius tincidunt.
        Nam hendrerit massa dui, eget viverra mi dignissim quis. Nulla facilisi. Aenean vel nisi eu urna lobortis varius. Maecenas ultricies eget felis sit amet luctus. Nulla eget mattis nunc. Quisque sit amet sem tortor. Morbi fringilla, dui sed ultricies consectetur, nunc justo ultricies mauris, ut fermentum ex sapien pharetra magna.

Aenean sit amet justo quis augue mollis auctor quis vitae lacus. Nam magna ex, vestibulum non libero ut, feugiat rutrum quam. Praesent ultrices eget ipsum sit amet lobortis. Donec faucibus nisl ante, eget tincidunt augue pretium vel. Vivamus nec ex vel nisi rhoncus varius sit amet nec nulla. Integer blandit in nisi et blandit. Morbi pretium vestibulum nunc. Sed sit amet lectus in ex aliquam placerat. Sed sit amet sapien ut est euismod tincidunt quis consectetur magna. Mauris euismod, lacus sit amet iaculis congue, metus sem luctus lectus, et rutrum purus magna ac dui. Ut diam magna, commodo id finibus at, luctus ut lorem. Fusce sodales metus et consequat tempus. Aliquam at velit vel metus congue viverra condimentum nec sem. Curabitur sit amet velit nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nisi eros, dictum ac porta in, facilisis quis urna.
        </p>
    </div>

    )
}