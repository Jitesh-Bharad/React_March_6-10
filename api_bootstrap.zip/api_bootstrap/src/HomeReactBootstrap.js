import { Button, Col, Container, Row } from "react-bootstrap";
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

export function HomeReactBootstrap(){
 
    return (

        <>
        <Container fluid>
        <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#home">Home</Nav.Link>
            <Nav.Link href="#link">Link</Nav.Link>
            <NavDropdown title="Dropdown" id="basic-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
                Another action
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Separated link
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
        </Container>

        <Container>
            <Row>
                <Col sm={12} md={4} style={{background:'green'}}>One</Col>
                <Col sm={12} md={4} style={{background:'orange'}}>Two</Col>
                <Col sm={12} md={4} style={{background:'gray'}}>Three</Col>
            </Row>
            <Row>
                <Col style={{background:'blue'}}>Four</Col>
                <Col style={{background:'yellow'}}>Five</Col>
            </Row>

            <Button variant="primary">Click</Button>
            <Button variant="success">Click</Button>
            <Button variant="danger">Click</Button>
            <Button variant="warning">Click</Button>
            {/* <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent faucibus elit dui, non maximus velit laoreet quis. Vivamus sagittis velit dui, at tristique orci semper sit amet. Praesent condimentum sapien eget tellus accumsan dignissim vel non sem. Vestibulum efficitur commodo tortor. Quisque varius ligula auctor dolor mattis feugiat. Curabitur pharetra libero ut pellentesque fermentum. Vivamus vitae pellentesque risus. Nulla pulvinar, quam in lacinia malesuada, lacus turpis elementum justo, vitae fermentum mauris dolor vitae nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam tempus neque et ante iaculis elementum. Phasellus sed sapien erat. Nulla facilisi. Aenean egestas nulla sed luctus vehicula.

Proin rutrum dictum sapien nec vestibulum. Nulla facilisi. Suspendisse semper magna non nulla finibus euismod. Quisque sodales, ex sit amet malesuada dapibus, felis nunc eleifend est, eu porttitor mi urna ac libero. Maecenas sagittis vel quam quis ullamcorper. Mauris id tellus lorem. Quisque condimentum in felis ac posuere. Maecenas lectus leo, molestie vel viverra et, cursus a eros. Etiam at lacus aliquam augue pretium rutrum eget id purus. Nulla facilisi. Sed semper neque id dolor mollis vulputate. Aenean pellentesque lacus ut pellentesque eleifend. Donec ac nibh felis.

Curabitur vitae fringilla est. Sed elit metus, maximus quis nibh et, posuere condimentum arcu. Nunc eget risus ac odio porttitor bibendum sit amet eget mauris. Sed lobortis lacinia urna, et porttitor augue dictum quis. Vivamus finibus felis rhoncus augue cursus, vel efficitur elit porttitor. Proin vitae sapien lorem. Proin in velit vel elit ultrices scelerisque eu a augue. Duis non suscipit mauris, quis tempor est. In ut viverra diam, efficitur maximus eros. Ut mauris metus, viverra quis lorem ac, pellentesque dictum justo. Donec vitae dolor lorem. Fusce rhoncus porttitor lorem, eu tempus turpis convallis at. Vestibulum et ante sed ligula posuere vulputate nec quis lacus. Sed fringilla, turpis eget fringilla ultricies, est augue porta lectus, ac tristique tortor orci eget lectus.

Mauris t
            </p> */}
        </Container>
        </>

    )
}