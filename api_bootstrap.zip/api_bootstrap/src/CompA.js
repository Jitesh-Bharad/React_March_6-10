import style from './CompA.module.css';

export function CompA()
{
    return (
        <div className={style.theme}>
        <h3>Comp A here</h3>
        <p>para1 of component A </p>
        </div>
    )
}