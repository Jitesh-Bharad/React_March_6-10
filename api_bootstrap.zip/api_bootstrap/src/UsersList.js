import axios from "axios";
import { useEffect, useState } from "react";

export function UsersList()
{
  const [error,setError]=useState('');
  const [users,setUsers] =useState([]);
  const[loading,setLoading]=useState(false);

  useEffect(()=>{
    async function fetchUsers()
    {
        try{
            setLoading(true);
            let url='https://jsonplaceholder.typicode.com/users';
            let response=await axios.get(url);
            let users=response.data;
            setUsers(users);
            setLoading(false);    
        }catch(error){
            let code=error.code;
            let message=error.message;
            let errorStr=`${code} : ${message}`;
            setError(errorStr);
            setLoading(false);
        }
    }
        fetchUsers();
  },[]) 

  
    if(loading){
        return (<p>...Loading</p>)
    }
    else{
        if(error==''){
            return(
                <table className="table">
                <thead>
                    <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user)=>( 
            <tr key={user.id}>
            <td>{user.name}</td>
            <td>{user.email}</td>
            <td>{user.phone}</td>
            </tr>
            ))}
          </tbody>
        </table>    
            )
    
        }else{
            return (
                <p>
                    {error}
                </p>
            )
        }
    }
  

}