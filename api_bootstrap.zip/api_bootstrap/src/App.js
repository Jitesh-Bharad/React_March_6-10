import logo from './logo.svg';
import './App.css';
import { Home } from './Home';
import { Conditional } from './Conditional';
import { ConditionalStyleState } from './ConditionalStyleState';
import { CompA } from './CompA';
import { CompB } from './CompB';
import {HomeBootstrap} from './HomeBootstrap';
import { UsersList } from './UsersList';
import { HomeReactBootstrap } from './HomeReactBootstrap';

function App() {
  return (
    // <Home></Home>
    // <Conditional theme='d'></Conditional>
    // <ConditionalStyleState></ConditionalStyleState>
    // <>
    // <CompA></CompA>
    // <CompB></CompB>
    // </>
    // <HomeBootstrap></HomeBootstrap>
    <UsersList></UsersList>
    // <HomeReactBootstrap></HomeReactBootstrap>
  );
}

export default App;
