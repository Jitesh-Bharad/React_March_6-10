import { connect } from "react-redux"
import { reset } from "./actions/ScoreActions";
import { mapDispatchToProps, mapStateToProps } from "./mappers"

function Test(props)
{
    return(
        <>
        <h2>Test</h2>
        <p>Score : {props.score}</p>
        <button onClick={()=>props.dispatch(reset(100))}>Reset to 100</button>
        </>
    )
}

export default connect(mapStateToProps,mapDispatchToProps)(Test);

