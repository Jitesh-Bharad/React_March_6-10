import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { scoreReducer } from './reducers/ScoreReducer';

const rootReducer=combineReducers({scoreReducer})

export const store=configureStore({reducer:rootReducer});