import { NavLink } from "react-router-dom";

export function Home()
{
    return (
        <>
        <h2>Home</h2>
        <ul>
            <li><NavLink to='/score'>Score</NavLink></li>
            <li><NavLink to='/detail'>Detail</NavLink></li>
            <li><NavLink to='/test'>Test</NavLink></li>
        </ul>
        </>
    )
}