import { DECREMENT_SCORE, INCREMENT_SCORE, RESET_SCORE } from "../actions/ActionTypes";

const initialState=10;

export function scoreReducer(prevState=initialState,action)
{
    const {type,payload}=action;

    switch(type)
    {
        case INCREMENT_SCORE:
            return prevState+1;
        case DECREMENT_SCORE:
            return prevState-1;
        case RESET_SCORE:
            return payload;
        default:
            return prevState;
    }
}