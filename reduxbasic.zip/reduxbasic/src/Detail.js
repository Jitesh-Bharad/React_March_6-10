import { useSelector } from "react-redux"

export function Detail()
{
    const score=useSelector((state)=>state.scoreReducer);
    return (
        <>
        <h2>Detail Page</h2>
        <p>Score : {score}</p>
        </>
    )
}