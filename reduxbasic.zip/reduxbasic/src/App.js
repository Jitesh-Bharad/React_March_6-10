import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Home } from './Home';
import { Score } from './Score';
import { Detail } from './Detail';
import Test from './Test';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home></Home>}></Route>
      <Route path='/score' element={<Score></Score>}></Route>
      <Route path='/detail' element={<Detail></Detail>}></Route>
      <Route path='/test' element={<Test></Test>}></Route>     
    </Routes>
    </BrowserRouter>
  );
}
export default App;
