export function mapStateToProps(state)
{
    return{
        score:state.scoreReducer
    }
}

export function mapDispatchToProps(dispatch)
{
    return{
        dispatch:dispatch
    }
}