import { DECREMENT_SCORE, INCREMENT_SCORE, RESET_SCORE } from "./ActionTypes";

export function increment()
{
    return {
        type:INCREMENT_SCORE
    }
}

export function decrement()
{
    return {
        type:DECREMENT_SCORE
    }
}

export function reset(value)
{
    return {
        type:RESET_SCORE,
        payload:value
    }
}