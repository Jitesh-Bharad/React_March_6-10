import { useState } from "react";
import { useDispatch, useSelector } from "react-redux"
import { decrement, increment, reset } from "./actions/ScoreActions";

export function Score()
{
    const score=useSelector((state)=>state.scoreReducer);
    const [defaultScore,setDefaultScore]=useState(0);
    const dispatch=useDispatch();

    function handleIncrementScore()
    {
        dispatch(increment());
    }
    function handleDecrementScore()
    {
        dispatch(decrement());
    }

    function handleChangeDefaultScore(e)
    {
        setDefaultScore(e.target.value);
    }

    function handleResetScore(value)
    {
        dispatch(reset(parseInt(value)))
    }

    return (
        <>
        <h2>Score : {score} </h2>
        <button onClick={handleIncrementScore}>+</button>
        <button onClick={handleDecrementScore}>-</button>  
        <input type='number' placeholder="Reset to" onChange={handleChangeDefaultScore}/>
        <button onClick={()=>{handleResetScore(defaultScore)}}>Reset</button>           
        </>
    )
}